#pragma once

namespace quadratic {
	static void quadCalc();
	double a;
	double b;
	double c;
}